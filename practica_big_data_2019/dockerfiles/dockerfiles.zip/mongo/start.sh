#!/bin/bash

systemctl start mongod
  


